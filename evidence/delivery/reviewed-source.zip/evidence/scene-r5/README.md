# HOW-SCENE-R5D-1 场景回接

2026-10-30。用户接受 R5c 祭坛与碎石密度，要求加白昼熄灭炭头、增强随机碎面后直接回接。现已接入本地 `codex/gathering-sources` 的主体源码；没有覆盖既有角色、采集、库存或完整存档。未开新 PR、合并或部署。

## 实现

- 溪流沿用已接受的倒影、碎光、绕石白沫和水滴。单个 512²/256² 目标，每 3/4 帧有界更新，不重复阴影。
- 地形沿实际崖沿切边，石/草法线分开，远处减点，侧壁与底部真实封闭。166 处碎面密度不变，插点的三个重心权重独立变化，深浅和正负起伏分别取样；16–36cm 左右的法向起伏更易辨认。固定坐标哈希保证重开不重抽，总计 19,896 三角形，23,000 上限未提高。
- 白昼篝火为灰黑焦木、十个低面炭头和灰烬端环，无火舌/烟/火星/辉光/局部照明；夜间恢复已接受的半透明外焰、亮芯、辉光与照明。13 条火舌仍为 2,808 三角形/3 次绘制。
- 原木架从统一库存各品质的 wood 总量派生，0–18 根逐根表现，超过部分保留准确读数。场景不扣/发原木。
- 祭坛保留下部顺坡石基与水平台阶，上部为七块悬浮环石、种核与细光轨。前沿三格供盘，纸页在右上方可点读；上部 37 网格、2,910 三角形、一张按状态更新的 512×640 纹理。正常模式供盘为空；四状态和供品示例在检视中呈现，正式供奉/奖励仍待 M2。

正常入口 `npm.cmd run dev`；`?inspect=1` 的“运行检查 → 场景检视”提供九个固定相机、昼夜与祭坛示例。检视暂停模拟并借用当前相机，结束/复位恢复角色跟随；正常操作不使用沙盒的固定相机 UI。视觉昼夜从 GameState.time 派生（候选 1,200 秒/日，起始 14:00），不是第二套时钟或正式日历。

## 兼容与检查

修改前源文件指纹、580 树位及合成旧存档在 [intake](intake.json)、[before-trees](before-trees.json)、[before-save](before-save.json)。新坡度不能改变旧树位筛选，故明确固定现有树位名单；身份、坐标、外观参数和个体代次逐项对照不变。合成旧档和新道具/神谕的选中状态均能保存/读取。巨木导航点向外移动两米以避开祭坛，ID 保留；所有风景路线仍需经过原碰撞/坡度检查。

[完整检查](check.log)包含 81 项测试、资产许可/字节检查、类型与构建。新增检查覆盖完整闭合/绕向、所有近处三角形内部高程、随机碎面密度、炭头昼夜开关、供盘与神谕、库存不被场景修改、纹理一次释放、旧档与固定树位。原“每格均为两三角”的断言改为未切草地插值，并由实际切分网格内部取样补足崖面；坡度退离测试选用新地表上的真实临界点，规则阈值未放宽。旧河面测试改为当前倒影实现的几何/水高不变、目标预算、冻结相位和释放检查。

旧角色回执保留原字节：组合根改动由 [capture-bridge](capture-bridge.json) 连接旧指纹与当前指纹；角色、握斧、接触等专属模块继续直接核对旧 hash。其余历史回执按原归档审计，最终结果见 [证据审计](history-evidence.log)。当前源、构建、文档和本轮图片绑定到 [source-freeze](source-freeze.json)，不会覆盖 R4 或各条支线的冻结证据。

## 实机证据

桌面 1440×900、手机 390×844；手机为同机视口仿真。PNG 是主体的实际 WebGL 画面，同名 JSON 有相机/视口、模拟时刻、灯光、几何和库存读数。全部在 [captures](captures/)；用户已接受的独立沙盒证据仍留原目录。

| 对象 | 本轮画面 |
| --- | --- |
| 白昼炭头 / 夜间火焰 | [白昼](captures/scene-desktop-fire-14-ready-1.png)、[夜间](captures/scene-desktop-fire-23-ready-2.png) |
| 更随机的崖面 | [桌面](captures/scene-desktop-cliffs-14-ready-3.png)、[手机](captures/scene-mobile-cliffs-14-answering-5.png) |
| 供品与神谕 | [桌面](captures/scene-desktop-ritual-14-ready-4.png)、[回应](captures/scene-desktop-ritual-23-answering-5.png)、[手机](captures/scene-mobile-ritual-14-ready-6.png) |
| 手机炭头 / 火焰 | [白昼](captures/scene-mobile-fire-14-answering-4.png)、[夜间](captures/scene-mobile-fire-23-answering-3.png) |

浏览器实际点读神谕，文案随待供奉/回应变化。手机新检视按钮最小高度 44px、宽度 74.5px。暂停检视切换时同步相机与场景矩阵，点选和画面保持一致。实际采集得枝料 3，实际采伐结算原木 5、已用额度 5/预留 0；[营地画面](captures/scene-desktop-camp-14-ready-6.png)与[溪流](captures/scene-desktop-creek-14-ready-7.png)的 JSON 保留这些余额。卸载重入后原木仍为 5、木架 5 根、枝料 3；旧循环停止、旧 camp/river 已释放，geometry/material/extra owner 清零，旧 renderer 计数为 geometry 0/texture 1，同名 JSON 的 audits 记录实际结果。当前页控制台无 error，shaderErrors 为 0。

[生产构建检查](production-smoke.json)通过：实际打开 dist 预览，加载 `/assets/index-BJ1HXIrW.js`，默认角色镜头、白昼炭头、崖面/溪流/祭坛正常，存档可用，无控制台或着色器错误。正式燃料经济、供奉交易、真实移动设备持续帧时与多指操作不在本轮验证中；既有单包体积提示保留。

## 去留与回退

本轮已获准回接。沙盒仍独立，旧 `review.html` 属于 R5c 历史审看，不作为当前主体入口。主体修改前的 11 个所有者文件留在本机 `.cache/scene-r5-before/`，白名单和差异在 intake/bridge；回退时须结合同时存在的其他未提交工作逐项恢复，不整包覆盖工作区。
