# 资产获取、工具使用与接入流程

2026-10-30 追加 HOW-CHARACTERS-1：按用户明确回接授权，只接入选定 KayKit Rogue、六段动作、重绘色图及本地斧头；原包 CC0、源文件 hash、修改与释放责任分别登记在 [ASSET_REGISTER](ASSET_REGISTER.md)。独立设计沙盒与整套素材包不进入运行时；完整可重建来源保留采用的部件和脚本。后续外观变更、PR 合并与部署另行记录。

对应 HOW-BASELINE-1.0；最初基线 PR 仅建立规范。当前 R4 已完成设计/空间试验、独立模型和运行时接入，并于 2026-10-30 获用户授权按白名单回接主体工作分支、准备实现 PR；实现分支待PR审查、未合并、未部署。以下流程持续约束当前及后续资产，不把回接授权外推为采购、合并或发布授权。

## 当前批次与证据

HOW-GATHERING-1 对旧本地 Kenney Nature Kit 2.1 包重新核对官方页和随包 CC0，逐项采用 campfire_logs 与 mushroom_tanGroup；没有继承旧试稿的准入或完成结论。`tools/build-gathering-assets.mjs` 做可复现 glTF 根节点/尺寸/材质修整，具体源部件和许可在 sources/kenney，产物加入既有 manifest。前后尺寸/hash 见 [asset-normalization](../evidence/gathering/asset-normalization.json)，两类在同一可玩功能包接入，验证见[本批证据](../evidence/gathering/README.md)。

本轮实际链路为 Midjourney R3 构图与局部编辑 → Atlas RGBD/多视图空间试验 → 人工审查地面锚点与玩法清理 → 统一地表及五个独立 Blender GLB → R4 林业、地被、雪山、天光、水面和 HUD。具体操作、失败分支与采用理由见 [R3 PIPELINE](../art-direction-r3/PIPELINE.md)；原始账号回执、临时链接和整景 SPZ 不进入公开回接包。

当前生产 GLB 是项目原创模型；Kenney 曾作为 CC0 候选审查，manifest 的 previousSource 不表示生产网格仍复用该候选，也不将生成参考统一标成 CC0。运行时文件、来源与 hash 由 [manifest](../public/assets/manifest.json)、[ASSET_REGISTER](ASSET_REGISTER.md) 和原 [R4 source-freeze](../evidence/r4/source-freeze.json) 追踪。Blender 重新导出存在极小浮点差异，保留规范运行时 GLB，差异说明见 [re-export-audit](../art/re-export-audit.json)。

回接清单与授权记录位于 [integration/intake.json](../evidence/integration/intake.json)；回接后的加载、构建、交互和资源检查另存 evidence/integration。原 R4 已取得的工程和实机证据仍由 [VERIFICATION](../VERIFICATION.md) 说明，不能靠复制证据目录给后续修改自动记为 verified。

## 1. 选择顺序与授权

优先选择 **CC0 等免费资源**，经统一修整后成批接入。优先级为：适配的 CC0/可确认公有领域资源 → 允许修改与公开分发的其他免费许可资源 → 有针对性的自制或获准工具生成。

候选必须核对具体资源包、版本、作者、来源和实际许可文件，而非仅看网站首页、免费标签或旧 FAQ。分别确认：获取成本、修改权、游戏使用权、公开仓库再分发权，以及必要署名。付费素材、新订阅或额外付费额度须另行授权；允许使用工具不等于购买授权。

- CC0 可用于复制、修改和分发等用途；仍检查第三方商标、人物肖像等独立权利，不宣称资源作者为项目背书。见 [CC0 官方说明](https://creativecommons.org/publicdomain/zero/1.0/)。
- CC BY 等免费许可可按具体条件采用，并保留作者、来源、许可、修改说明及要求的其他通知。见 [CC BY 4.0](https://creativecommons.org/licenses/by/4.0/)。带额外义务的许可单独审查，不自动混入项目统一许可。
- 来源不明、NC/ND 与当前用途不兼容、仅限特定引擎、禁止独立再分发或无法证明可公开入库的文件，不进入运行时或公开素材目录；选择可替代资源。
- 原资源许可证与项目代码许可证分别保留。修整、重绘或生成处理不自动清除原输入的授权义务，不能统一改标 CC0。

## 2. 候选资源入口（不是批准清单）

| 入口 | 用途与核验要求 |
| --- | --- |
| [Kenney](https://kenney.nl/support) | 低多边形、道具与 UI 候选；官方资产页说明 CC0，仍保留具体包许可。 |
| [Poly Haven](https://polyhaven.com/license) | 模型/材质/环境候选；区分 CC0 资产与非资产网页/示例图，写实资源需风格化处理。 |
| [Quaternius FAQ](https://quaternius.com/faq.html) / [许可页](https://quaternius.com/license.html) | 按具体包核验。核对时 FAQ 与 QAL 许可页范围并不一致；QAL 含独立再分发限制，不能把整个站点当 CC0 白名单。 |

上述官方页面于 2026-10-29 核对；实际取得资源时再次核验版本与随包许可。网站名不等于每一份下载的授权证明。

## 3. Midjourney：设计稿

允许用于山谷构图、配色、角色、建筑、季节和道具设计稿。先按 ART_HUD 给出同一风格与比例需求，再选择方向；记录模型版本、用途、简要生成信息、输入来源和实际账号适用的输出条件，不上传私人资料或无权处理的参考图。

使用官方允许的操作方式；本项目不预设第三方非官方 API 或脚本自动化。实际使用时核验 [条款](https://docs.midjourney.com/hc/en-us/articles/32083055291277-Terms-of-Service) 与 [使用说明](https://docs.midjourney.com/hc/en-us/articles/27870375276557-Using-Images-Videos-Commercially)。生成稿不自动标为 CC0。

设计稿用于审稿和模型修整方向；不能代替独立模型、碰撞、动作或实机截图。纳入仓库前同样检查输出权利及输入素材约束。本轮实际沿用用户已登录页面，比较少量 Draft 候选，使用屋顶局部蒙版、清晰度编辑与 Reframe 扩图；采用和淘汰分别登记在 R3 PIPELINE。用户指定最多每分钟提交一次、优先 Draft；局部编辑输出按实际模式记录，不把所有 Edit 都称为 Draft。后续继续遵循这项频率和用量约束。

## 4. Marble 2：场景建立与交互原型

允许用于山谷空间建立、场景构图、可漫游空间与交互试验。具体操作与导出能力按账号当时已开放的接口执行，不把通用 Marble 功能、预览能力或不同版本能力当作本账号已具备。

实际使用前核验 [Marble 2 文档](https://marble5.worldlabs.ai/docs/quickstart)、[API 能力](https://marble5.worldlabs.ai/docs/api-reference) 与 [World Labs 条款](https://docs.worldlabs.ai/terms-of-service)。工具权限、导出权利、公开入库/发布条件和成本记录在资源条目，不在仓库写入密钥、签名 URL 或账号身份。本轮实际完成 Atlas 图像转配对 RGBD、平移视图、三视图 Draft splat 和局部网格提取；扩展视图失败及有界重试已如实登记。大角度视图存在缺面和漂浮斑块，整景网格不可分离，均未作为整块经营区接入。

导入后统一坐标、尺度、材质、地表与碰撞；把可经营树、巨木资源点、可修缮建筑、道路和交互锚点接入本项目 world/domain。交互动作转成现有命令，库存、时间、额度、再生与存档仍由本地游戏拥有。

整景 splat、贴图或不可拆模型仅作经过审查的景观候选。可采伐树和修缮建筑必须是独立实体，不以整景烘焙替代。生成服务不成为运行时必需依赖；不得用外部漫游演示替代本游戏交互验收。

## 5. 一个可见功能包的流程

1. **候选与授权**：围绕阶段列出少量候选；核对具体许可、输入权利、公开分发和成本，在 ASSET_REGISTER 建记录。未通过前只保留合法的来源信息，不把文件提交公开仓库。
2. **统一修整**：在 Blender 或等价工具中统一轴向、尺度/枢轴、轮廓、法线、材质/色板、UV、纹理大小、骨骼/动画、LOD、碰撞与命中体。移除未用节点、材质和高频写实细节，按 ART_HUD 调整成同一套玩具风格。
3. **可复现导出**：优先 GLB/glTF；记录源包版本/校验值、使用部件、修整摘要、导出工具/版本/设置、产物校验值。需要的源文件在许可允许且体量合理时保留；不能只留下无法追溯的导出结果。
4. **成批接入**：同一体验所需模型、材质、动画、状态映射、导入缓存、碰撞/拾取和 UI 图标在同一批次接入。只包含使用到的文件，按需加载，不把全素材库和实验输出打进游戏。
5. **实机验收**：固定 seed/视角/状态检查整体比例、光照、季节/成长切换、动作、碰撞/命中、手机可读性、性能与资源释放。记录当前提交证据，旧试稿不得代替。
6. **登记与交付**：更新资产状态、运行时路径、署名/许可证和证据；本批通过后才记为 integrated/verified。概念稿可 approved-for-reference，不能标为运行时已集成。

建议批次：家园与邻近林地（M0）；修屋工具、材料与动作（M1）；四季、行商与扩建（M2）。批次可调整，资产与交互必须共同收口。

## 6. 入库最小记录与检查

具体记录格式见 [ASSET_REGISTER](ASSET_REGISTER.md)。每个运行时资产可追到来源文件、许可依据、修改过程和游戏入口；CC0 也记录出处以便维护。对于要求署名的许可，必要通知同时出现在分发物与适当的游戏署名入口。

当前已建立 public/assets/manifest.json 与 public/assets/licenses/，后续批次在同一登记体系补充实际产物，不预填假资源或通过结果。R4 的模型、地表来源、缓存与释放已有原冻结版本检查；当前实现 PR 仍需完成主体回接复核。若新增加载器、材质或资源缓存代码，相应 PR 同时验证加载失败回退、重复进入释放与共享资源不被误销毁。

本基线之前的所有试稿默认未准入。需要复用时，从候选授权和风格审查重新进入本流程；旧展示效果、旧测试通过或旧使用记录均不构成豁免。

## 2026-10-30 R5d 场景回接

用户已批准选定 R5 成果进入主体。本轮不整包覆盖沙盒 runtime/UI；按白名单适配场景、地表、碰撞、点选与资源释放，保留现有角色、库存和世界存档。原创网格与文字纹理、MIT Reflector、预算和实机记录见 [资产登记](ASSET_REGISTER.md)及[回接证据](../evidence/scene-r5/README.md)。沙盒历史源码/截图保持独立归属。
