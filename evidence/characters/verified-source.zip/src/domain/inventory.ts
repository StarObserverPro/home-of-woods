export type InventoryState = { version: number; quantities: Record<string, number> };
export const createInventory = (): InventoryState => ({ version: 0, quantities: {} });
export function inventoryCandidate(state: InventoryState, itemId: string, delta: number): InventoryState {
  const quantity = (state.quantities[itemId] ?? 0) + delta;
  if (!Number.isSafeInteger(delta) || !Number.isSafeInteger(quantity) || quantity < 0) throw new Error('Invalid inventory transaction');
  return { version: state.version + 1, quantities: { ...state.quantities, [itemId]: quantity } };
}
