import type { GatheringRegistry } from './gathering-registry.ts';
import type { InventoryState } from './inventory.ts';
export type WarehouseItemView = {
  itemId: string; name: string; icon: string; category: 'wood' | 'forest-produce';
  quantity: number; description: string; source: string; tags: readonly string[];
  processing: { id: string; name: string; outputs: string[]; station: string; status: string; parametersReady: boolean }[];
};
export type WarehouseView = { items: WarehouseItemView[]; total: number; occupiedKinds: number };
export function warehouseSnapshot(state: { inventory: InventoryState; forestry: { wood: number } }, registry: GatheringRegistry): WarehouseView {
  const items = [...registry.items.values()].filter(i => i.balance !== 'catalog').map(i => ({
    itemId: i.itemId, name: i.name, icon: i.icon, category: i.category, description: i.description, source: i.source, tags: i.tags,
    quantity: i.balance === 'forestry-wood' ? state.forestry.wood : state.inventory.quantities[i.itemId] ?? 0,
    processing: registry.processing.forItem(i.itemId).map(p => ({ id: p.processingId, name: p.name,
      outputs: p.outputs.map(o => registry.items.get(o.itemId)!.name), station: p.station,
      status: p.status === 'planned' ? '后续开放' : '已登记', parametersReady: p.durationSeconds !== null && [...p.inputs,...p.outputs].every(m=>m.quantity!==null),
    })),
  }));
  return { items, total: items.reduce((sum,i)=>sum+i.quantity,0), occupiedKinds: items.filter(i=>i.quantity>0).length };
}
