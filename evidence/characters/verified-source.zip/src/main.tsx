import { createRoot } from "react-dom/client";
import { App } from "./ui/App.tsx";
import "./ui/style.css";
createRoot(document.getElementById("root")!).render(<App />);
