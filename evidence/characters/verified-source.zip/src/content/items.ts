export type ItemDefinition = {
  itemId: string; name: string; category: 'wood' | 'forest-produce'; icon: string;
  tags: readonly string[]; description: string; source: string;
  resourceLine: 'small-wood' | 'structure-wood' | 'forest-produce';
  balance: 'inventory' | 'forestry-wood' | 'catalog';
};
export const ITEMS: readonly ItemDefinition[] = [
  { itemId: 'branch', name: '枝杈', category: 'wood', icon: '枝', tags: ['轻修缮', '小木作'], description: '从树下拾起的小型枝料，和建筑原木分别保管。', source: '对应树木的树下落枝', resourceLine: 'small-wood', balance: 'inventory' },
  { itemId: 'mushroom', name: '蘑菇', category: 'forest-produce', icon: '菇', tags: ['森林物产'], description: '从树种对应的树下蘑菇圈采得。', source: '松下、栎下的蘑菇圈', resourceLine: 'forest-produce', balance: 'inventory' },
  { itemId: 'wood', name: '原木', category: 'wood', icon: '木', tags: ['建筑木材', '限额采伐'], description: '合法采伐所得的原木，受年度体量额度约束。', source: '获准采伐的成熟经营树', resourceLine: 'structure-wood', balance: 'forestry-wood' },
  { itemId: 'small-wood', name: '小木料', category: 'wood', icon: '料', tags: ['加工材料'], description: '枝杈整理后的候选材料，加工方式尚待接入。', source: '枝杈加工', resourceLine: 'small-wood', balance: 'catalog' },
  { itemId: 'dried-mushroom', name: '干蘑菇', category: 'forest-produce', icon: '干', tags: ['加工物产'], description: '蘑菇晾制后的候选物产，加工方式尚待接入。', source: '蘑菇加工', resourceLine: 'forest-produce', balance: 'catalog' },
];
