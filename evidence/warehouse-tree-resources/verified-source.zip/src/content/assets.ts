export const RUNTIME_MODELS = [
  { name: 'cabin', assetId: 'how-m0-cabin', url: '/assets/m0/cabin.glb' },
  { name: 'tent', assetId: 'how-m0-tent', url: '/assets/m0/tent.glb' },
  { name: 'ranger', assetId: 'how-m0-ranger', url: '/assets/m0/ranger.glb' },
  { name: 'pine', assetId: 'how-m0-pine', url: '/assets/m0/pine.glb' },
  { name: 'broadleaf', assetId: 'how-m0-broadleaf', url: '/assets/m0/broadleaf.glb' },
  { name: 'branches', assetId: 'how-gathering-branches', url: '/assets/gathering/branches.glb' },
  { name: 'mushrooms', assetId: 'how-gathering-mushrooms', url: '/assets/gathering/mushrooms.glb' },
] as const;
